#Set working directory, import packages, source functions, 
setwd(paste(directory,"/source/", sep = ''))    # set temp working directory 

#import packages
library(strataG)

#source functions
source(paste(getwd(), "/RunSims.R", sep = ''))

